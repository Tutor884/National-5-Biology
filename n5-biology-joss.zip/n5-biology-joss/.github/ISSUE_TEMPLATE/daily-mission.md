---
name: Daily mission
about: One day's N5 Biology mission
title: 'Day XX — '
labels: mission
---

**Mission file:** `days/day-XX.md`
**Key area:**

## Checklist

- [ ] ⚡ Warm-up (3 min, no notes)
- [ ] 📖 Core drill (6 min)
- [ ] ✍️ Exam reps written out (8 min)
- [ ] 🏆 Boss question attempted
- [ ] Marked honestly against the answers
- [ ] Lost marks added to Repeat Offenders in `SCOREBOARD.md`

## Score

XP earned:

## Anything I got wrong
